# Personal Assistant Agent

A beginner-friendly Streamlit web app with:
- Task creation
- Task listing and deletion
- Study-time planner

## Run locally
```bash
python -m pip install -r requirements.txt
streamlit run streamlit_app.py
```

## Deploy
Upload `streamlit_app.py` and `requirements.txt` to a GitHub repository, then deploy that repository using Streamlit Community Cloud. Set the app entrypoint to `streamlit_app.py`.

Note: JSON-file storage is suitable for a demo. Cloud local files may not persist reliably across restarts/rebuilds; use a database for production.
